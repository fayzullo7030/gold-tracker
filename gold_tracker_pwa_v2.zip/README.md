# Gold Tracker PWA

PWA для отслеживания цены 5-граммового золотого слитка ЦБ Узбекистана.

## Архитектура

- GitHub Pages — только публикация статических файлов.
- GitHub Actions — один раз в день в 09:35 по Ташкенту получает страницу ЦБ.
- `data.json` — простой файл с историей; БД не используется.
- Телефон хранит полученную историю локально в IndexedDB.
- Приложение при открытии синхронизируется с `data.json`.
- Если телефон был выключен или приложение не открывали, данные всё равно собираются GitHub Actions.
- Никакого CORS-запроса с телефона к cbu.uz нет.

Источник: https://cbu.uz/ru/banknotes-coins/gold-bars/prices/

## GitHub Pages

Repository → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

После публикации адрес будет:

https://fayzullo7030.github.io/gold-tracker/

## GitHub Actions

Repository → Actions. Убедитесь, что workflow разрешён.

Расписание `35 4 * * *` = 09:35 Asia/Tashkent (UTC+5).

Workflow можно запустить вручную через **Run workflow**, чтобы не ждать следующего дня.
